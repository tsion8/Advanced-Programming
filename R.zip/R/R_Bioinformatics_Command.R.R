# =====================================================
# R Programming & Bioinformatics Analysis
# Author: Tsion Legesse (GSR/1433/18)
# =====================================================


# Install packages if needed
# install.packages("knitr")
# BiocManager::install("Biostrings")


library(knitr)
library(Biostrings)


# =====================================================
# Question 1: Basic R Programming
# =====================================================


# Create gene expression vector

expression <- c(
  120,135,98,145,
  160,178,155,132
)


# Calculate statistics

mean_expression <- mean(expression)

median_expression <- median(expression)

sd_expression <- sd(expression)

maximum_expression <- max(expression)

minimum_expression <- min(expression)


# Create results table

results <- data.frame(
  Statistic = c(
    "Mean",
    "Median",
    "Standard Deviation",
    "Maximum",
    "Minimum"
  ),
  
  Value = c(
    round(mean_expression,2),
    round(median_expression,2),
    round(sd_expression,2),
    maximum_expression,
    minimum_expression
  )
)


results


# Bar plot

barplot(
  expression,
  names.arg = paste("Sample",1:8),
  col = "steelblue",
  border = "black",
  main = "Gene Expression Values",
  xlab = "Samples",
  ylab = "Expression Value"
)



# =====================================================
# Question 2: Gene Expression Data Frame
# =====================================================


genes <- data.frame(
  Gene = c("TP53","BRCA1","MYC","EGFR"),
  Sample1 = c(120,100,200,180),
  Sample2 = c(150,125,260,240)
)


# Display first two rows

head(genes,2)


# Calculate average expression

genes$Average <- rowMeans(
  genes[,c("Sample1","Sample2")]
)


genes


# Gene with highest Sample2 expression

highest_gene <- genes[
  which.max(genes$Sample2),
]


highest_gene



# =====================================================
# Question 3: Sequence Analysis Using Biostrings
# =====================================================


# Create FASTA file

writeLines(
  c(
    ">Gene1",
    "ATGGCTAGCTAGCTAGCTA",
    
    ">Gene2",
    "ATGCGCGCGCTTTAGCTA",
    
    ">Gene3",
    "ATTTTTTTGGGGCCCCAAA"
  ),
  "genes.fasta"
)



# Read FASTA file

dna <- readDNAStringSet(
  "genes.fasta"
)


dna



# Sequence length

sequence_length <- data.frame(
  Sequence = names(dna),
  Length = width(dna)
)


sequence_length



# Nucleotide frequency

nucleotide_frequency <- alphabetFrequency(
  dna,
  baseOnly = TRUE
)


nucleotide_frequency



# GC content calculation

gc_content <- round(
  (
    letterFrequency(dna,"G") +
      letterFrequency(dna,"C")
  ) /
    width(dna) * 100,
  2
)


gc_table <- data.frame(
  Sequence = names(dna),
  GC_Content = gc_content
)


gc_table



# Sequence with highest GC content

highest_gc <- gc_table[
  which.max(gc_table$GC_Content),
]


highest_gc




# =====================================================
# Question 4: RNA-Seq Gene Expression Analysis
# =====================================================


rna_data <- data.frame(
  Gene = c(
    "TP53",
    "BRCA1",
    "MYC",
    "EGFR",
    "KRAS"
  ),
  
  Control = c(
    100,
    200,
    300,
    150,
    250
  ),
  
  Treatment = c(
    250,
    220,
    700,
    600,
    275
  )
)


rna_data



# Fold Change calculation

rna_data$FoldChange <- round(
  rna_data$Treatment /
    rna_data$Control,
  2
)


rna_data



# Genes with Fold Change > 2

differential_genes <- rna_data[
  rna_data$FoldChange > 2,
]


differential_genes



# Fold Change bar plot

barplot(
  rna_data$FoldChange,
  names.arg = rna_data$Gene,
  col = "#5C4033",
  border = "black",
  main = "Gene Fold Changes",
  xlab = "Genes",
  ylab = "Fold Change"
)


abline(
  h = 2,
  col = "red",
  lty = 2
)
