#!/usr/bin/perl
use strict;
use warnings;

# ==================================
# Exercise 1: Basic Perl Variables
# ==================================

my $gene_name = "EDN3";
my $chromosome = "chr13";
my $length = 2156;

print "Gene: $gene_name\n";
print "Chromosome: $chromosome\n";
print "Length: $length\n\n";


# ==================================
# Exercise 2: Arrays and Loops
# ==================================

my @genes = ("EDN3", "PDE5A", "DNAH7", "IKBKG");

foreach my $gene (@genes) {
    print "$gene\n";
}
print "\n";


# ==================================
# Exercise 3: Hashes
# ==================================

my %gene_length = (
    EDN3  => 2156,
    PDE5A => 3245,
    DNAH7 => 8540
);

print "EDN3 length = $gene_length{EDN3}\n\n";


# ==================================
# Exercise 4: DNA Sequence Statistics
# ==================================

my $seq = "ATGCGCGATATCGCGAT";

my $len = length($seq);

my $g_count = ($seq =~ tr/G/G/);
my $c_count = ($seq =~ tr/C/C/);

my $gc_count = $g_count + $c_count;
my $gc_percent = ($gc_count / $len) * 100;

print "Length: $len\n";
print "GC Count: $gc_count\n";
printf "GC%%: %.2f\n\n", $gc_percent;


# ==================================
# Exercise 5: Reverse Complement
# ==================================

my $dna = "ATGCCGAAT";

my $revcomp = reverse($dna);
$revcomp =~ tr/ATGC/TACG/;

print "Reverse Complement: $revcomp\n\n";


# ==================================
# Exercise 6: Restriction Enzyme Finder (EcoRI)
# ==================================

my $seq2 = "ATCGAATTCGGGGAATTCATC";
my $pattern = "GAATTC";

while ($seq2 =~ /$pattern/g) {
    my $pos = pos($seq2) - length($pattern) + 1;
    print "EcoRI found at position $pos\n";
}
print "\n";


# ==================================
# Exercise 7: FASTA File Reader
# ==================================

# Example FASTA file: fasta.txt
# >gene1
# ATGCGCGATCG
# >gene2
# ATGGGGCCCAA

my $file = "fasta.txt";
open(my $fh, "<", $file) or die "Cannot open file: $!";

my $id = "";
my $sequence = "";

while (my $line = <$fh>) {
    chomp $line;

    if ($line =~ /^>(\S+)/) {
        if ($id ne "") {
            my $len = length($sequence);
            print "$id $len\n";
        }
        $id = $1;
        $sequence = "";
    } else {
        $sequence .= $line;
    }
}

# print last record
if ($id ne "") {
    my $len = length($sequence);
    print "$id $len\n";
}

close($fh);
print "\n";


# ==================================
# Exercise 8: BioPerl FASTA Parsing
# ==================================

use Bio::SeqIO;

my $in = Bio::SeqIO->new(
    -file   => "fasta.txt",
    -format => "fasta"
);

while (my $seq_obj = $in->next_seq) {
    print "ID: " . $seq_obj->id . "\n";
    print "Length: " . $seq_obj->length . "\n";
    print "First 10 bp: " . $seq_obj->subseq(1,10) . "\n\n";
}


# ==================================
# Exercise 9: GenBank Retrieval (BioPerl)
# ==================================

use Bio::DB::GenBank;

my $gb = Bio::DB::GenBank->new();

my $acc = "NM_174738";
my $seq_obj = $gb->get_Seq_by_acc($acc);

print "Accession: $acc\n";
print "Description: " . $seq_obj->desc . "\n";
print "Length: " . $seq_obj->length . "\n\n";


# ==================================
# Exercise 10: BLAST Parsing (BioPerl)
# ==================================

use Bio::SearchIO;

my $blast_file = "blast.out";

my $searchio = Bio::SearchIO->new(
    -format => "blast",
    -file   => $blast_file
);

while (my $result = $searchio->next_result) {
    while (my $hit = $result->next_hit) {

        while (my $hsp = $hit->next_hsp) {

            print $hit->name . "\t";
            print $hsp->evalue . "\t";
            print sprintf("%.1f", $hsp->percent_identity) . "\n";
        }
    }
}
